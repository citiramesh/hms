package com.order;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepositroy extends JpaRepository<OrderVO, Integer>{

}
